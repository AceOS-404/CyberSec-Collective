# Blue Team — defensive-security learning (planned)

**Status:** Not started; prospective collaborator has not confirmed participation.

Potential future investigations include Wireshark traffic interpretation, log collection, Splunk searches and dashboards, Microsoft Sentinel/KQL, and incident reporting. No work is attributed to another person until they have agreed to participate and actually contributed it.

When a study is completed, create a dated folder including scope, data source, queries, alert/detection rationale, screenshots, false positives, and conclusion. Avoid publishing sensitive logs or personal identifiers.
