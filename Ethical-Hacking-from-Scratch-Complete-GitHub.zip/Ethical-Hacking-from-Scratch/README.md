# Ethical Hacking from Scratch | ACEOS Security Labs

**Practical cybersecurity learning portfolio** — Kali Linux, virtualisation, network fundamentals, authorised wireless security labs, and reproducible technical reporting.

> **Scope:** This is an educational portfolio. Work is performed in isolated, fictional, public training, or explicitly authorised environments. No unauthorised access, real passwords, private captures, or instructor-owned course content is published.

## Verified progress

| Lab | Status | Evidence |
| --- | --- | --- |
| Kali-on-Kali VirtualBox setup | Completed | [Environment notes](docs/ENVIRONMENT.md) |
| Core tools and command-line checks | Completed | [Tool verification](Red-Team/01-Tooling-and-Network-Fundamentals/README.md) |
| **Public WPA handshake offline verification** | **Successful — `KEY FOUND! [ 12345678 ]`** | [Lab report and screenshot](Red-Team/02-Offline-WPA-Verification/README.md) |
| Simulated `DillenLab` WPA2 access point | Partial — AP enabled; client did not connect | [Troubleshooting report](Red-Team/03-Simulated-WiFi-Troubleshooting/README.md) |
| Blue-team investigations | Planned; collaborator participation unconfirmed | [Blue Team](Blue-Team/README.md) |
| Joint purple-team exercises | Planned | [Purple Team](Purple-Team/README.md) |

## Repository structure

```text
Red-Team/
  01-Tooling-and-Network-Fundamentals/
  02-Offline-WPA-Verification/
    screenshots/
  03-Simulated-WiFi-Troubleshooting/
    configs/
Blue-Team/
Purple-Team/
docs/
scripts/
.github/ISSUE_TEMPLATE/
```

## Primary result

A known public Aircrack-ng test capture, `wpa2.eapol.cap`, was processed in a Kali Linux VirtualBox guest with Aircrack-ng 1.7. The tool detected a WPA handshake for the **public sample ESSID `Harkonen`** and verified a test candidate, returning **`KEY FOUND! [ 12345678 ]`** after **3/3 candidates tested**. This demonstrates **offline password verification against a pre-existing sample capture**, *not* gaining access to a live network. See the [lab report](Red-Team/02-Offline-WPA-Verification/README.md) for commands, evidence, and limits.

## Collaboration

This project began as an individual red-team learning log. A possible blue-team collaborator has been invited but **has not yet been confirmed**. If collaboration begins, work will be tracked separately in **Red-Team**, **Blue-Team**, and shared **Purple-Team** experiments. See [CONTRIBUTING.md](CONTRIBUTING.md).

## References

- [Kali Linux](https://www.kali.org/)
- [Aircrack-ng](https://www.aircrack-ng.org/)
- [Aircrack-ng source / public test resources](https://github.com/aircrack-ng/aircrack-ng)
- [Oracle VirtualBox](https://www.virtualbox.org/)
- Studying *Learn Ethical Hacking From Scratch* by Zaid Sabih / zSecurity (independent student notes; not affiliated with or redistributing the course)

**Disclaimer:** These notes document observed results and learning. They are not a professional penetration-test report or certification.
