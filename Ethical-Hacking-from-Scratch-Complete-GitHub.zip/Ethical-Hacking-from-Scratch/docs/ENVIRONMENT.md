# Environment, versions and scope

Recorded from user-provided screenshots and statements; not a complete machine inventory.

| Layer | Recorded configuration |
| --- | --- |
| Laptop OS | Kali Linux installed directly |
| Host wireless | Realtek RTL8821CE (not assumed adequate for course injection) |
| Host kernel | `7.1.5+kali-amd64` -> `7.2.15+kali-amd64` after upgrade |
| Hypervisor | Oracle VirtualBox from Kali repository |
| Guest | Official Kali Linux 2026.3 prebuilt VirtualBox image |
| Guest memory | 4 GiB |
| Guest CPU | 2 vCPUs |
| Guest network | NAT |
| Confirmed tools | Nmap, Wireshark, Tshark, Tcpdump, Aircrack-ng, Airodump-ng, Aireplay-ng, Macchanger, Python 3 |

A virtual machine's NAT virtual Ethernet device **is not** a physical Wi-Fi radio and does not provide actual over-the-air monitor mode or packet injection. `mac80211_hwsim` simulates radio interfaces *in software*; it was attempted but not fully functional for association during this session.
