# Contributing to the security labs

This portfolio currently documents one student's work. A prospective blue-team collaborator has been invited, **but no participation has been confirmed**.

Please use branches and pull requests rather than working directly on `main`. Each practical report should state purpose, authorised scope, environment, exact steps, evidence, mistakes and their correction, results, limitations, and defensive takeaways. Report failures as failures; do not infer success from tool startup messages alone. Use only data you are entitled to share.

To join: accept a repository collaborator invitation, create a feature branch (for example `blue/wireshark-basics`), add a report and redacted screenshots, then open a pull request for review. Names are credited only with consent.
