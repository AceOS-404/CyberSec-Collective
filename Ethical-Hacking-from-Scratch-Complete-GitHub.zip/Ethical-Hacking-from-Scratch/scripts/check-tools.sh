#!/usr/bin/env bash
set -eu
for tool in nmap wireshark tshark tcpdump aircrack-ng airodump-ng aireplay-ng macchanger python3; do
  if command -v "$tool" >/dev/null 2>&1; then
    echo "[OK] $tool"
  else
    echo "[MISSING] $tool"
  fi
done
