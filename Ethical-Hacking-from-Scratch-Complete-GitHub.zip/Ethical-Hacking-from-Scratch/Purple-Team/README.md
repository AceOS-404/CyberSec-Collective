# Purple Team — shared learning (planned)

The proposed arrangement pairs a **red-team** exercise in an owned/authorised environment with an independent **blue-team** observation and a joint remediation review. These are future intentions, not finished projects.

Template for a joint lab:

1. Agree on written scope and expected signal.
2. Red team documents the authorised test and timestamps.
3. Blue team independently collects evidence and explains what was/wasn't visible.
4. Joint review tests proposed detections and mitigations.
5. Attribute each contributor with their consent.

Don't publish identifiable people, operational targets, or copied course handouts.
