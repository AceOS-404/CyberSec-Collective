# Lab 02 — Offline WPA handshake verification with Aircrack-ng

**Status:** ✅ Successful offline verification with a public training capture  
**Date:** 2026-11-23 (documentation date; commands performed during the study session)  
**Environment:** Kali Linux 2026.3 VirtualBox guest, 4 GiB RAM, 2 vCPUs, NAT  
**Tool:** Aircrack-ng 1.7  
**Scope:** Public Aircrack-ng sample capture with deliberately known training password. Not a household, live, or third-party network.

## Objective

Understand the division of responsibilities between wordlist generation and WPA handshake password verification; demonstrate a correct password candidate being accepted for a known sample EAPOL capture without a Wi-Fi adapter.

## Preparation and command sequence

Run inside a private, isolated Kali training VM. Download the public sample from its upstream repository:

```bash
mkdir -p ~/wpa2-lab && cd ~/wpa2-lab
curl -fL -o wpa2.eapol.cap \
  https://raw.githubusercontent.com/aircrack-ng/aircrack-ng/master/test/wpa2.eapol.cap
```

The original short demonstration wordlist contained three candidate lines:

```bash
printf 'wrongpassword\nFrosty12\n12345678\n' > demo-wordlist.txt
```

Verify the supplied **public training capture** against the candidates:

```bash
aircrack-ng -a 2 -w demo-wordlist.txt wpa2.eapol.cap
```

### Observed result

The submitted terminal screenshot establishes:

```text
Aircrack-ng 1.7
Opening wpa2.eapol.cap
Read 5 packets.
1 potential targets
[00:00:00] 3/3 keys tested (52.26 k/s)
KEY FOUND! [ 12345678 ]
```

Earlier output identified the capture ESSID as **Harkonen**, encryption **WPA (1 handshake)**. The `KEY FOUND!` text, tested-candidate count, and key-material fields are visible in the actual screenshot. The screenshot does **not** show a successful connection to a Wi-Fi network, and that is not claimed.

### Evidence

![Aircrack-ng shows KEY FOUND for a public training capture](screenshots/aircrack-ng-key-found-public-sample.jpg)

*Figure 1: First demonstrated positive offline password-verification result in the public sample. Only the instructor-independent tool output is shown.*

## What this proves — and what it does not

- ✅ Aircrack-ng can process the supplied sample handshake capture.
- ✅ A candidate in a short demonstration wordlist produced a cryptographic match.
- ✅ The exercise can run without a physical wireless adapter because the capture is already available.
- ❌ It does **not** demonstrate sniffing or injecting packets over the air.
- ❌ It does **not** show the simulated `DillenLab` authentication completed.
- ❌ It does **not** grant access to a network, recover an account login, or imply permission to test someone else's Wi-Fi.

## Key concepts learned

- **Crunch** generates candidate passwords; **airodump-ng** captures supported wireless frames; **aircrack-ng** tests candidates against suitable handshake data.
- A WPA/WPA2 MIC verification is not a 'nearly correct' score; candidates pass or fail the verification.
- WPA2-Personal passphrases generally have **8–63 characters**, with no mandatory uppercase/special-character rule in WPA2 itself.
- The default Kali **OS login** is unrelated to a Wi-Fi network passphrase.

## Next learning tasks

- Revisit handshake frame structure and explain EAPOL messages and derived keys in an original diagram.
- Produce a separate, explicitly fictional complete client-connection and capture demonstration after resolving virtual radio problems.
- Add blue-team interpretation of wireless authentication logs as a separate exercise when appropriate.
