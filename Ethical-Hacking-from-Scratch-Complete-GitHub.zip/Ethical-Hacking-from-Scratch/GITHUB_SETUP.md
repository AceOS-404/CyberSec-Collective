# GitHub upload guide

1. Create a public GitHub repository named `Ethical-Hacking-from-Scratch`.
2. When creating it, leave **Add README**, **.gitignore**, and **License** disabled; the project already includes README and .gitignore.
3. Download this ZIP and extract it to a normal folder.
4. Open the newly created GitHub repository and select **uploading an existing file** or **Add file -> Upload files**.
5. Upload **the contents of the `Ethical-Hacking-from-Scratch` folder**, preserving the directory structure. Do not upload only the ZIP file.
6. Review the proposed files for secrets, then commit with message `docs: add verified Kali and WPA training labs`.
7. Open README and verify the evidence link renders properly.
8. Invite any collaborator only after they agree. Under repository **Settings -> Collaborators and teams**, grant the least necessary access.

**Note:** GitHub web uploads can have file/folder and size limitations. If directory upload is awkward, use `git` locally and push. Avoid committing genuine passwords, captures or large wordlists.
