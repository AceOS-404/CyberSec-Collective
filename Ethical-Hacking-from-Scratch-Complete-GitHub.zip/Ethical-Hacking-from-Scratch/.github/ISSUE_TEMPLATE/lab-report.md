---
name: Lab report
about: Record a reproducible authorised lab
---

## Objective
## Scope and authorisation
## Environment
## Steps taken
## Evidence (redacted)
## Observed result
## Limitations / failures
## Defensive relevance
## Lessons learned
