# Lab 03 — Simulated wireless AP / client troubleshooting

**Status:** Partially completed; **not a verified successful handshake capture**.

## Setup

Inside the Kali virtual machine, the Linux `mac80211_hwsim` radio simulator was available. Two simulated radios appeared as `wlan0` (on `phy0`) and `wlan1` (on `phy1`). This enabled a controlled attempt to create the fictional SSID `DillenLab` with the **lab-only** WPA2 passphrase `Frosty12`.

## Observed sequence

1. `modinfo mac80211_hwsim` located the simulator module.
2. `sudo modprobe mac80211_hwsim radios=2` exposed two simulated wireless interfaces, confirmed by `iw dev`.
3. `hostapd` was installed, and a configuration was created for `DillenLab`.
4. Initial errors resulted from typing `nl80211` incorrectly and misspelling `wpa_passphrase`; corrected configuration led to **`AP-ENABLED`**.
5. A second `wpa_supplicant` configuration initially failed to parse; after correction the supplicant started.
6. The supplicant saw the intended SSID but **did not reach `CTRL-EVENT-CONNECTED`**. Output included repeated `handle_probe_req: send failed`, `CTRL-EVENT-SCAN-FAILED ret=-16`, authentication retries, and temporary SSID disable events.
7. `rfkill` did not report a soft or hard block on the simulated radios.

## Example configurations

The two files in [`configs/`](configs/) are **fictional lab-only examples**, not harvested credentials. Do not apply them to a production network.

## Interpretation

The AP service starting is **not equivalent** to successful station association or a captured four-way handshake. The reported errors suggest an unresolved simulated-radio/driver or interface-state issue. No cause was proven; the user chose to proceed to an offline public capture rather than continue repeating diagnostics.

## Follow-up

If revisited, record interface ownership, radio channel, actual kernel messages, full `hostapd` / supplicant logs, and a successful association before claiming a reproducible handshake. Stop programs before reconfiguring the simulated radios.
