# Lab 01 — Kali toolchain and network foundations

**Status:** Completed setup and tool-presence verification; network fundamentals are ongoing learning.

## Environment

- Host: Kali Linux on HP laptop (bare-metal installation). Observed host kernel upgraded from `7.1.5+kali-amd64` to `7.2.15+kali-amd64` for VirtualBox compatibility.
- Hypervisor: Oracle VirtualBox installed using Kali packages.
- Guest: Kali Linux 2026.3 VirtualBox prebuilt VM; 4 GiB memory, 2 vCPUs; NAT networking.
- Guest internet and updates: reported successful.

## Core software verified

The following tools returned success in the command-path check: `nmap`, `wireshark`, `tshark`, `tcpdump`, `aircrack-ng`, `airodump-ng`, `aireplay-ng`, `macchanger`, `python3`.

```bash
for tool in nmap wireshark tshark tcpdump aircrack-ng airodump-ng aireplay-ng macchanger python3; do
  command -v "$tool" >/dev/null && echo "[OK] $tool" || echo "[MISSING] $tool"
done
```

## Installation issue actually encountered

An initial package installation met mismatched dependencies; a subsequent `apt --fix-broken install` attempt encountered an incomplete/corrupt cached `libgcc-15-dev` archive (`lzma error` / unexpected end of stream). Clearing the download cache with `sudo apt clean` and retrying the repair was reported successful, after which the tools were installed.

## Foundational concepts reviewed

Client requests/server responses, local MAC addressing versus network-layer IP addresses, routing, DNS, wireless radio frames versus internet cloud infrastructure, Wi-Fi monitoring versus packet injection versus authenticated access. A localhost Nmap service scan was proposed but **no output was supplied**, so this report does not call it completed.
