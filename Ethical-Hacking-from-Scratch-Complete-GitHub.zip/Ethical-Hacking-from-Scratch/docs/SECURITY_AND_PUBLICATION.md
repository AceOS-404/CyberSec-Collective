# Ethical boundaries and publishing rules

- Use public demo data, fictional environments, or systems within explicit, documented authorisation.
- Do not upload passwords in use, credentials, API tokens, SSH keys, private packets, identifiable MAC addresses, private IP inventories, or third-party data.
- Public sample capture remains on its upstream source; reference it instead of adding it to Git history.
- Keep instructor-owned course downloads, slides, and transcripts out of the repository.
- Do not confuse an offline password match with a real-world compromise or log-in.
- Obtain each collaborator's permission before naming them in public or adding their identity as a contributor.
- Check screenshots for user names, addresses and accidental sensitive windows before publishing.
